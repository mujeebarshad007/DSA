template <typename T>
struct dnode
{
    T value;
    dnode *next;
    dnode *prev;
};