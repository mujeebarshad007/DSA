template <typename T>
struct node
{
    T value;
    node *link;
};